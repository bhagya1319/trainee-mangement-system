from django.contrib import admin
from django.urls import path
from users import views
from django.shortcuts import redirect
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', lambda request: redirect('login/')),
    path('login/', views.login, name='login'),
    path('sign_up/', views.sign_up, name='sign_up'),
    path('logout/', views.logout, name='logout'),
    path('forgot_password/', views.forgot_password, name='forgot_password'),
    path("verify-otp/", views.verify_otp, name="verify_otp"),
    path('reset_password/', views.reset_password, name='reset_password'),
    path("verify-otp_reset/", views.verify_otp_reset, name="verify_otp_reset"),
    path('hr_dashboard/', views.hr_dashboard, name='hr_dashboard'), 
    path('add-hr/', views.add_hr, name='add_hr'),
    path('hr_view_trainings/', views.hr_view_trainings, name='hr_view_trainings'),
    path('training-order/create/', views.create_training_order, name='create_training_order'),
    path('hr_view_applications/', views.hr_view_applications, name='hr_view_applications'),
    path('hr_edit_profile/', views.hr_edit_profile, name='hr_edit_profile'),
    path('edit_training_order/<int:training_no>/', views.edit_training_order, name='edit_training_order'),
    path('delete_training_order/<int:training_no>/', views.delete_training_order, name='delete_training_order'),
    path('certificate/<int:application_no>/', views.download_certificate, name='download_certificate'),
    path('download_approved_applications/', views.download_approved_applications, name='download_approved_applications'),
    path('download_completed_trainings/', views.download_completed_trainings, name='download_completed_trainings'),
    path('applicant_dashboard/', views.applicant_dashboard, name='applicant_dashboard'),
    path('applicant_view_trainings/', views.applicant_view_trainings, name='applicant_view_trainings'),
    path('apply/<int:training_no>/', views.apply, name='apply'),
    path('applicant_view_applied_trainings/', views.applicant_view_applied_trainings, name='applicant_view_applied_trainings'),
    path('applicant_view_application_details/<int:training_no>/', views.applicant_view_application_details, name='applicant_view_application_details'),
    path('applicant_edit_profile/', views.applicant_edit_profile, name='applicant_edit_profile'),
    path('track/', views.track_application, name='track_application'),
    path('resubmit/<str:training_no>/<str:application_no>/', views.resubmit, name='resubmit'),
    path('resend-otp/', views.resend_otp, name='resend_otp'),

    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
  urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

