from django import forms
from .models import TrainingOrder, Application, Applicant,DepartmentHr

class LoginForm(forms.Form):
    cpf = forms.CharField(label="CPF", required=True,max_length=30, widget=forms.TextInput(attrs={'placeholder': 'Enter CPF'}))
    password = forms.CharField(label="Password", required=True,widget=forms.PasswordInput(attrs={'placeholder': 'Enter Password'}))
    
    def clean_cpf(self):
        cpf = self.cleaned_data['cpf']
        return str(cpf).strip()    

class ApplicantForm(forms.ModelForm):
    confirm_password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = Applicant
        fields = ['name', 'cpf', 'email', 'password']
        widgets = {
            'password': forms.PasswordInput(),
        }

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password and password != confirm_password:
            raise forms.ValidationError("Passwords do not match.")

class TrainingOrderForm(forms.ModelForm):
    
    class Meta:
        model = TrainingOrder
        fields = [
            'training_name', 'no_of_participants', 'qualifying_criteria', 
            'start_date', 'end_date', 'submission_date', 'mode', 
            'training_venue', 'instructor_organiser', 'remarks', 
            'training_order_form'
        ]
    def clean_training_order_form(self):
        file = self.cleaned_data.get('training_order_form')
        if file:
            allowed_types = ['application/pdf', 'image/jpeg', 'image/png']

            if file.size > 5 * 1024 * 1024:  # 5MB
                raise forms.ValidationError("File size should not exceed 5MB.")

        return file
    start_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    submission_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))  
    training_order_form = forms.FileField(required=False,help_text="Allowed file types: PDF, JPEG, PNG. Max file size: 5MB.")
   

class ApplicationForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = [
            'dob', 'mobile_no', 'department', 'caste', 
            'designation', 'gender', 'applicant_form',
        ]

    dob = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'})
    )
    def clean_applicant_form(self):
        file = self.cleaned_data.get('applicant_form')
        if file:
            allowed_types = ['application/pdf', 'image/jpeg', 'image/png']

            content_type = getattr(file, 'content_type', None)
            if content_type not in allowed_types:
                raise forms.ValidationError("Only PDF, JPEG, or PNG files are allowed.")

            if file.size > 5 * 1024 * 1024:  
                raise forms.ValidationError("File size should not exceed 5MB.")

        return file
    applicant_form = forms.FileField(required=False,help_text="Allowed file types: PDF, JPEG, PNG. Max file size: 5MB.")
   

class ApplicationStatusForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ['status']        

class ApplicantEditForm(forms.ModelForm):
    old_password = forms.CharField(widget=forms.PasswordInput, required=False, label="Old Password")
    new_password = forms.CharField(widget=forms.PasswordInput, required=False, label="New Password")
    confirm_password = forms.CharField(widget=forms.PasswordInput, required=False, label="Confirm New Password")

    class Meta:
        model = Applicant
        fields = ['name', 'email']

    def clean(self):
        cleaned_data = super().clean()
        old_password = cleaned_data.get("old_password")
        new_password = cleaned_data.get("new_password")
        confirm_password = cleaned_data.get("confirm_password")

        if new_password or confirm_password:
            if not old_password:
                raise forms.ValidationError("Old password is required to change password.")
            if new_password != confirm_password:
                raise forms.ValidationError("New password and confirm password do not match.")
        return cleaned_data  

class HRForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, label="Password")
    confirm_password = forms.CharField(widget=forms.PasswordInput, label="Confirm Password")

    class Meta:
        model = DepartmentHr
        fields = [
            'cpf', 'name', 'password', 'confirm_password','email' ,'designation',
            'department', 'gender', 'caste', 'mobile_no'
        ]
        widgets = {
            'gender': forms.Select(choices=[('M', 'Male'), ('F', 'Female')]),
            'caste': forms.Select(choices=[('GENERAL', 'GENERAL'), ('OBC', 'OBC'), ('ST', 'ST'), ('SC', 'SC')]),
        }

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        if password and confirm_password and password != confirm_password:
            self.add_error('confirm_password', "Passwords do not match.")
        return cleaned_data 

    def save(self, commit=True):
        hr = super().save(commit=False)
        hr.role = 'HR'
        password = self.cleaned_data.get('password')
        if password:
            hr.password = make_password(password)  
        if commit:
            hr.save()
        return hr