from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission
from django.core.validators import RegexValidator
class TrainingOrder(models.Model):
    training_no = models.AutoField( primary_key=True)
    training_name = models.CharField(max_length=255, unique=True)
    no_of_participants = models.IntegerField()
    qualifying_criteria = models.TextField()
    start_date = models.DateField()
    end_date = models.DateField()
    submission_date = models.DateField()
    mode = models.CharField(max_length=15, default='Offline',choices=[('Offline', 'Offline'), ('Online', 'Online')])
    training_venue = models.CharField(max_length=255)
    instructor_organiser = models.CharField(max_length=255)
    remarks = models.TextField(null=True, blank=True)
    training_order_form = models.FileField(upload_to='training_order/',null=True, blank=True)
    created_by = models.ForeignKey('DepartmentHr', on_delete=models.SET_NULL,null=True, blank=True,to_field='cpf') 

    class Meta:
        db_table = 'TrainingOrder' 

    def __str__(self):
        return str(self.training_no)

class Applicant(models.Model):
    name = models.CharField(max_length=100)
    cpf = models.CharField(primary_key=True,max_length=30)
    password = models.CharField(unique=True,max_length=100)
    email = models.EmailField(max_length=100, unique=True)
    email_verified = models.BooleanField(default=False) 
    class Meta:
        db_table = 'Applicant' 
    def __str__(self):
        return f"{self.cpf}"

class Application(models.Model):
    cpf = models.ForeignKey('Applicant', on_delete=models.SET_NULL,null=True, blank=True,to_field='cpf')
    application_no = models.AutoField(primary_key=True, unique=True ) 
    name = models.CharField(max_length=100)  
    dob = models.DateField()  
    mobile_no = models.CharField(
        max_length=10,
        validators=[RegexValidator(r'^\d{10}$', message="Enter a valid 10-digit phone number.")],
    )  
    department = models.CharField(max_length=10, default='', choices=[('UAN','UAN' ), ('UAS','UAS' ),('AAFB','AAFB'),('BMF','BMF'),('SP','SP'),('LOG','LOG'),('RGS','RGS')])  
    caste = models.CharField(
        max_length=7, default='GENERAL',
        choices=[('GENERAL', 'GENERAL'), ('OBC', 'OBC'), ('ST', 'ST'), ('SC', 'SC')] 
    )
    designation = models.CharField(max_length=50)
    email = models.EmailField(max_length=100)  
    gender = models.CharField(
        max_length=6, default='M',
        choices=[('M', 'Male'), ('F', 'Female')]  
    )
    applicant_form = models.FileField(upload_to='applicant_forms/',null=True, blank=True)
    training_order = models.ForeignKey('TrainingOrder', to_field='training_no', on_delete=models.SET_NULL,null=True, blank=True)  
    applied_on = models.DateField(auto_now_add=True)  
    status = models.CharField(
        max_length=50, choices=[('Applied', 'Applied'), ('Approved', 'Approved'), ('Rejected', 'Rejected')], default='Applied',
    )
    training_status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Completed', 'Completed')], default='Pending')
    feedback = models.TextField(blank=True, null=True)
    class Meta:
        db_table = 'Application' 

    def __str__(self):
        return f"Application {self.application_no} - {self.training_order_id}"


class DepartmentHr(models.Model):
    cpf = models.CharField(primary_key=True,max_length=100)  
    name = models.CharField(max_length=100) 
    password = models.CharField(max_length=100,unique=True)
    designation = models.CharField(max_length=50)  
    department = models.CharField(max_length=10, choices=[('UAN','UAN'),('UAS','UAS'),('AAFB','AAFB'),('BMF','BMF'),('SP','SP'),('LOG','LOG'),('RGS','RGS')])  
    gender = models.CharField(max_length=1, default='M', choices=[('M', 'Male'), ('F', 'Female')])  
    caste = models.CharField(max_length=50, default='GENERAL',choices=[('GENERAL', 'GENERAL'), ('OBC', 'OBC'), ('ST', 'ST'), ('SC', 'SC')])  
    email = models.EmailField(max_length=100, unique=True)  
    role = models.CharField(max_length=10,default='HR', choices=[('ADMIN','ADMIN'),('HR','HR')]) 
    mobile_no = models.CharField(
        max_length=10,
        unique=True,
        validators=[RegexValidator(r'^\d{10}$', message="Enter a valid 10-digit phone number.")],
    )
    
    class Meta:
        db_table = 'DepartmentHr'
        
    def __str__(self):
        return f"{self.name} - CPF: {self.cpf}"
