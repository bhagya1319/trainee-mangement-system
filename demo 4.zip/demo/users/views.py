from django.shortcuts import render, redirect , get_object_or_404
from django.contrib import messages
from django.contrib.messages import get_messages
from .models import Applicant,DepartmentHr,Application,TrainingOrder
from .forms import LoginForm,TrainingOrderForm,ApplicationForm,ApplicationStatusForm,ApplicantForm,ApplicantEditForm,HRForm
from django.forms import modelformset_factory
from datetime import date
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from django.http import HttpResponse
from reportlab.platypus import Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from django.views.decorators.cache import never_cache
import random
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.hashers import check_password
from django.contrib.auth.hashers import make_password
from django.db.models import Q
from django.utils.timezone import now 
from reportlab.lib.pagesizes import A4

@never_cache
def login(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            cpf = str(form.cleaned_data['cpf']).strip()  
            password = form.cleaned_data['password']
            try:
                hr = DepartmentHr.objects.get(cpf=cpf)
                if check_password(password, hr.password): 
                    request.session['role'] = 'hr'
                    request.session['cpf'] = hr.cpf
                    return redirect('hr_dashboard')

            except DepartmentHr.DoesNotExist:
                pass

            try:
                applicant = Applicant.objects.get(cpf=cpf)
                if check_password(password, applicant.password): 
                    request.session['role'] = 'applicant'
                    request.session['cpf'] = applicant.cpf
                    return redirect('applicant_dashboard')
            except Applicant.DoesNotExist:
                pass

            messages.error(request, "Invalid CPF or Password.")  
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})

@never_cache
def sign_up(request):
    if request.method == "POST":
        form = ApplicantForm(request.POST)

        if form.is_valid():
            name = form.cleaned_data['name']
            cpf = form.cleaned_data['cpf']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            confirm_password = form.cleaned_data['confirm_password']

            if password != confirm_password:
                messages.error(request, "Passwords do not match")
                return redirect('sign_up')

            if Applicant.objects.filter(cpf=cpf).exists():
                messages.error(request, "Applicant with this Cpf already exist")
                return redirect('sign_up')

            if Applicant.objects.filter(email=email).exists():
                messages.error(request, "Applicant with this Email already exists")
                return redirect('sign_up')

            if password != confirm_password:
                messages.error(request, "Passwords do not match")
                return redirect('sign_up')

            otp = send_otp(email)
            if otp:
                signup_data = form.cleaned_data
                signup_data['password'] = make_password(password)
                request.session['signup_data'] = signup_data
                request.session['otp'] = otp
                request.session['email'] = email
                request.session.set_expiry(300)
                return redirect('verify_otp')
            else:
                messages.error(request, "Failed to send OTP . Try again")
                return redirect('sign_up')
        else:
            for field in form:
                for error in field.errors:
                    messages.error(request, error)
            for error in form.non_field_errors():
                messages.error(request, error)
            return render(request, 'sign_up.html', {'form': form})
    else:
        form = ApplicantForm()

    return render(request, 'sign_up.html', {'form': form})

def send_otp(email):
    """Generate and send a 5-digit OTP via email."""
    otp = str(random.randint(10000, 99999))
    subject = "Your OTP for Verification"
    message = f"Your OTP is: {otp}. Please enter it to verify your email."
    sender_email = settings.EMAIL_HOST_USER

    try:
        send_mail(subject, message, sender_email, [email])
        return otp
    except Exception as e:
        print(f"Email error: {e}")
        return None

def resend_otp(request):
    if request.method == "POST":
        email = request.session.get("email")
        if not email:
            messages.error(request, "Email not found in session. Please sign up again.")
            return redirect("sign_up")  
        otp = str(random.randint(10000, 99999))
        subject = "Your OTP for Verification"
        message = f"Your OTP is: {otp}. Please enter it to verify your email."
        sender_email = settings.EMAIL_HOST_USER

        try:
            send_mail(subject, message, sender_email, [email])
            request.session['otp'] = otp  # Save OTP to session
            messages.success(request, "A new OTP has been sent to your email.")
        except Exception as e:
            print(f"Email error: {e}")
            messages.error(request, "Failed to send OTP. Please try again later.")

        return redirect("verify_otp")

def verify_otp(request):
    """Handles OTP verification"""
    if request.method == "POST":
        entered_otp = request.POST.get('otp')
        stored_otp = request.session.get('otp')
        signup_data = request.session.get('signup_data')

        if stored_otp and entered_otp == stored_otp:
            Applicant.objects.create(
                name=signup_data['name'],
                cpf=signup_data['cpf'],
                password=signup_data['password'],  
                email=signup_data['email'],
                email_verified=True  
            )
            messages.success(request, "Your account has been successfully created.")
            del request.session['otp']
            del request.session['signup_data'] 
            return render(request, 'login')
        else:
            messages.error(request, "Invalid OTP. Try again.")

    return render(request, 'verify_otp.html')

@never_cache    
def logout(request):
    request.session.flush() 
    return redirect('login')

def forgot_password(request):
    """Handles email OTP verification for password reset."""
    if request.method == "POST":
        email = request.POST.get('email')
        cpf = request.POST.get('cpf')
        if not email:
            messages.error(request, "Email is required.")
            return render(request, 'forgot_password.html')
        if not cpf:
            messages.error(request, "CPF is required.")
            return render(request, 'forgot_password.html') 

        user= Applicant.objects.filter(email=email, cpf=cpf).exists() or DepartmentHr.objects.filter(email=email, cpf=cpf).exists()

        if not user:
            messages.error(request, "No account found with this email.")
            return render(request, 'forgot_password.html')

        otp = send_otp(email)
        if otp:
            request.session['otp'] = otp
            request.session['reset_email'] = email
            request.session['reset_cpf'] = cpf 
            request.session.set_expiry(300)  
            return redirect('verify_otp_reset')  

        messages.error(request, "Failed to send OTP. Try again.")
    
    return render(request, 'forgot_password.html')

def reset_password(request):
    """Allow user to enter a new password after OTP verification."""
    email = request.session.get('reset_email')
    cpf = request.session.get('reset_cpf')
    if not email or not cpf:
        messages.error(request, "Session expired. Try again.")
        return redirect('forgot_password')

    if request.method == "POST":
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        if not new_password or not confirm_password:
            messages.error(request, "All fields are required.")
            return render(request, 'reset_password.html')

        if new_password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, 'reset_password.html')
        
        hashed_password = make_password(new_password)
        applicant_updated = Applicant.objects.filter(email=email, cpf=cpf).update(password=hashed_password)
        hr_updated = DepartmentHr.objects.filter(email=email, cpf=cpf).update(password=hashed_password)

        if applicant_updated or hr_updated:
            del request.session['reset_email']
            del request.session['reset_cpf']
            messages.success(request, "Password reset successfully. You can now log in.")
            return render(request, 'reset_password.html', {'show_success_modal': True})

        messages.error(request, "Something went wrong. Try again.")
    return render(request, 'reset_password.html')

def verify_otp_reset(request):
    """Verify OTP for password reset."""
    if request.method == "POST":
        entered_otp = request.POST.get('otp')
        stored_otp = request.session.get('otp')

        if stored_otp and entered_otp == stored_otp:
            del request.session['otp']  
            return redirect('reset_password')  
        else :
            messages.error(request, "Invalid or expired OTP. Try again.")
    
    return render(request, 'verify_otp_reset.html')

@never_cache
def hr_dashboard(request):
    cpf = request.session.get('cpf')  
    if 'cpf' not in request.session:
        messages.error(request, "You are not logged in to access the dashboard.")
        return redirect('login') 
    try:
        hr = DepartmentHr.objects.get(cpf=cpf) 
    except DepartmentHr.DoesNotExist:
        messages.error(request, "HR profile not found.")
        return redirect('login')

    training_orders = TrainingOrder.objects.all()
    applications = Application.objects.all()
    issued_training_order_count = TrainingOrder.objects.filter(created_by=cpf).count()
    training_order_count = training_orders.count()
    application_count = applications.count()
    today = date.today()
    return render(request, 'hr_dashboard.html', {
        'hr': hr,
        'training_orders': training_orders,
        'training_order_count': training_order_count,
        'application_count': application_count,
        'issued_training_order_count': issued_training_order_count,
        'today': today,
    })

@never_cache
def applicant_dashboard(request):
    cpf = request.session.get('cpf')  
    if not cpf:
        messages.error(request, "You must be logged in to access the dashboard.")
        return redirect('login')

    try:
        applicant = Applicant.objects.get(cpf=cpf)
    except Applicant.DoesNotExist:
        messages.error(request, "Applicant not found.")
        return redirect('login')

    applications = Application.objects.filter(cpf=applicant)   
    training_orders = TrainingOrder.objects.all()
    training_order_count = training_orders.filter(submission_date__gte=date.today()).count()
    applied_training_count = applications.filter(Q(status='Applied') | Q(status='Approved') | Q(status='Rejected')).count()

    return render(request, 'applicant_dashboard.html', {
        'applicant': applicant,
        'training_order_count': training_order_count,
        'applied_training_count': applied_training_count,
    })


@never_cache
def applicant_view_trainings(request):
    cpf = request.session.get('cpf')  
    if not cpf:
        messages.error(request, "You must be logged in to view applications.")
        return redirect('login')
    training_orders = TrainingOrder.objects.filter(submission_date__gte=date.today())
    return render(request, 'applicant_view_trainings.html', {
        'training_orders': training_orders
    }) 

@never_cache
def applicant_view_applied_trainings(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to view applications.")
        return redirect('login')

    applicant = get_object_or_404(Applicant, cpf=cpf)
    applications = Application.objects.filter(cpf=applicant)
    applied_trainings = TrainingOrder.objects.filter(training_no__in=[application.training_order.training_no for application in applications])
    return render(request, 'applicant_view_applied_trainings.html', {'applied_trainings': applied_trainings})  

@never_cache
def applicant_view_application_details(request, training_no):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to view application details.")
        return redirect('login')
    training = get_object_or_404(TrainingOrder, training_no=training_no)
    application = Application.objects.filter(training_order=training,cpf=cpf).first()
    return render(request, 'applicant_view_application_details.html', {'training': training, 'application': application})   

@never_cache
def applicant_edit_profile(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to edit your profile.")
        return redirect('login')

    try:
        applicant = Applicant.objects.get(cpf=cpf)
    except Applicant.DoesNotExist:
        messages.error(request, "Applicant not found.")
        return redirect('login')

    if request.method == 'POST':
        form = ApplicantEditForm(request.POST, instance=applicant)
        if form.is_valid():
            old_password = form.cleaned_data.get('old_password')
            new_password = form.cleaned_data.get('new_password')

            if new_password:
                if not check_password(old_password, applicant.password):
                    messages.error(request, "Old password is incorrect.")
                    return redirect('applicant_edit_profile')
                applicant.password = make_password(new_password)
                messages.success(request, "Password updated successfully.")
            form.save()
            messages.success(request, "Profile details modified successfully.")
            return render(request, 'applicant_dashboard.html', {'applicant': applicant})

        else:
            for error in form.non_field_errors():
                messages.error(request, error)
        
    else:
        form = ApplicantEditForm(instance=applicant)

    return render(request, 'applicant_edit_profile.html', {'form': form, 'applicant': applicant})

@never_cache
def apply(request, training_no):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to apply.")
        return redirect('login')

    try:
        applicant = Applicant.objects.get(cpf=cpf)
    except Applicant.DoesNotExist:
        messages.error(request, "Applicant not found.")
        return redirect('applicant_dashboard')

    try:
        training = TrainingOrder.objects.get(training_no=training_no)
    except TrainingOrder.DoesNotExist:
        messages.error(request, "Training not found.")
        return redirect('applicant_view_trainings')

    if Application.objects.filter(cpf=applicant, training_order=training).exclude(status='Rejected').exists():
        messages.error(request, "You have already applied for this training.")
        return redirect('applicant_view_trainings')

    if request.method == "POST":
        form = ApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            application = form.save(commit=False)
            application.cpf = applicant
            application.name = applicant.name
            application.email = applicant.email
            application.training_order = training
            application.status = 'Applied'
            application.date_applied = now().date()
            application.save()
            messages.success(request, "applied successfully.")
            return redirect('applicant_view_trainings')
        else:
            messages.error(request, "Error in form. Please check the fields.")
    else:
        form = ApplicationForm()

    return render(request, 'apply.html', {
        'form': form,
        'applicant': applicant,
        'training_order': training,
    })

@never_cache
def resubmit(request, training_no, application_no):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to resubmit.")
        return redirect('login')

    try:
        applicant = Applicant.objects.get(cpf=cpf)
    except Applicant.DoesNotExist:
        messages.error(request, "Applicant not found.")
        return redirect('applicant_dashboard')

    try:
        training = TrainingOrder.objects.get(training_no=training_no)
    except TrainingOrder.DoesNotExist:
        messages.error(request, "Training not found.")
        return redirect('applicant_view_trainings')

    try:
        application = Application.objects.get(application_no=application_no, cpf=applicant, training_order=training, status='Rejected')
    except Application.DoesNotExist:
        messages.error(request, "Resubmission not allowed for this application.")
        return redirect('track_application')

    if request.method == "POST":
        form = ApplicationForm(request.POST, request.FILES, instance=application)
        if form.is_valid():
            form.instance.status = 'Applied'
            form.instance.feedback = ''
            form.instance.date_applied = now().date()
            form.save()
            messages.error(request, "Resubmitted the application successfully")
            return redirect('track_application')

            
        else:
            messages.error(request, "Error in resubmission form.")
    else:
        form = ApplicationForm(instance=application)

    return render(request, 'resubmit.html', {
        'form': form,
        'applicant': applicant,
        'training_order': training,
        'application': application,
    })

@never_cache
def track_application(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to track your application.")
        return redirect('login')

    try:
        applicant = Applicant.objects.get(cpf=cpf)
    except Applicant.DoesNotExist:
        messages.error(request, "Applicant not found.")
        return redirect('login')

    applications = Application.objects.filter(cpf=applicant)
    return render(request, 'track_application.html', {
        'applications': applications,
        'today_date': date.today()
    })

@never_cache
def hr_view_trainings(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to apply.")
        return redirect('login') 

    try:
        hr = DepartmentHr.objects.get(cpf=cpf)
    except DepartmentHr.DoesNotExist:
        messages.error(request, "HR not found.")
        return redirect('hr_dashboard') 

    training_orders = TrainingOrder.objects.filter(created_by=hr.cpf).order_by('-submission_date')

    context = {
        'training_orders': training_orders,
    }
    return render(request, 'hr_view_trainings.html', context)

@never_cache
def add_hr(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to create training order.")
        return redirect('login')
    try:
        hr = DepartmentHr.objects.get(cpf=cpf)
    except DepartmentHr.DoesNotExist:
        messages.error(request, "HR not found.")
        return redirect('hr_dashboard') 
    
    if hr.role != 'ADMIN': 
        return redirect('hr_dashboard')

    if request.method == 'POST':
        form = HRForm(request.POST)
        if form.is_valid():
            hr = form.save(commit=False) 
            hr.save()
            messages.success(request, "HR added successfully!")
            return redirect('hr_dashboard')  
    else:
        form = HRForm()
    return render(request, 'add_hr.html', {'form': form})

@never_cache
def create_training_order(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to create training order.")
        return redirect('login')
    try:
        hr = DepartmentHr.objects.get(cpf=cpf)
    except DepartmentHr.DoesNotExist:
        messages.error(request, "You are not authorized to create training orders.")
        return redirect('login')

    if request.method == 'POST':
        form = TrainingOrderForm(request.POST, request.FILES)
        
        if form.is_valid():
            training_order = form.save(commit=False)
            training_order.created_by = hr
            training_order.save()
            messages.success(request, "Training order created successfully.")
            return redirect('hr_dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = TrainingOrderForm()
    return render(request, 'create_training_order.html', {'form': form, 'hr': hr})

@never_cache
def hr_view_applications(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to view applications.")
        return redirect('login')

    try:
        department_hr = DepartmentHr.objects.get(cpf=cpf)
    except DepartmentHr.DoesNotExist:
        messages.error(request, "Department HR not found.")
        return redirect('hr_dashboard')

    training_orders = TrainingOrder.objects.all()
    selected_training_no = request.POST.get('training_no') or request.session.get('selected_training_no')
    applications = Application.objects.none()

    if selected_training_no:
        request.session['selected_training_no'] = selected_training_no
        applications = Application.objects.filter(training_order__training_no=selected_training_no)

    if request.method == "POST":
        if 'approve_reject' in request.POST:
            application_no = request.POST.get('application_no')
            new_status = request.POST.get('status')
            feedback = request.POST.get('feedback', '').strip()
            application_no = int(application_no)
            try:
                application = Application.objects.get(application_no=application_no)
                if application.department != department_hr.department:
                    messages.error(request, "Permission denied.")
                    return redirect('hr_view_applications')

                application.status = new_status

                if new_status == "Rejected":
                    if not feedback:
                        messages.error(request, "Please provide feedback for rejection.")
                        return redirect('hr_view_applications')
                    application.feedback = feedback
                    application.training_status = "Pending"

                elif new_status == "Approved":
                    application.feedback = ""

                application.save()
                messages.success(request, f"Application status updated to {new_status}.")

            except Application.DoesNotExist:
                messages.error(request, "Application not found.")
            return redirect('hr_view_applications')

        elif 'mark_completed' in request.POST:

            application_no = request.POST.get('mark_completed_application_no')
            if not application_no.isdigit():
                messages.error(request, "Invalid application number for completion.")
                return redirect('hr_view_applications')

            application_no = int(application_no)
            try:
                application = Application.objects.get(application_no=application_no)
                if (application.status == "Approved" and 
                        application.training_order.end_date < date.today()):
                    application.training_status = 'Completed'
                    application.save()
                    messages.success(request, f"Application no {application_no} marked as completed.")
                else:
                    messages.error(request, "Cannot mark as completed before training ends or if not approved.")
            except Application.DoesNotExist:
                messages.error(request, "Application not found.")
            return redirect('hr_view_applications')

    context = {
        'department_hr': department_hr,
        'training_orders': training_orders,
        'applications': applications,
        'selected_training_no': selected_training_no,
        'today_date': date.today(),
    }

    return render(request, 'hr_view_applications.html', context)


@never_cache
def edit_training_order(request, training_no):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to edit training orders.")
        return redirect('login')

    hr = DepartmentHr.objects.get(cpf=cpf)

    training = get_object_or_404(TrainingOrder, training_no=training_no)
    if request.method == 'POST':
        if 'delete_form' in request.POST:
            if training.training_order_form:
                training.training_order_form.delete()  
                training.training_order_form = None  
                training.save() 
                messages.success(request, "File deleted successfully.")
            return redirect('edit_training_order', training_no=training.training_no)  

        form = TrainingOrderForm(request.POST, request.FILES, instance=training)
        if form.is_valid():
            form.save()
            messages.success(request, "File modified successfully.")
            return redirect('hr_view_trainings')
        else:
            messages.error(request, "Error updating training order. Please check the form.")

    else:
        form = TrainingOrderForm(instance=training)

    return render(request, 'edit_training_order.html', {
        'form': form,
        'training': training,
        'hr': hr,
    })


@never_cache
def delete_training_order(request, training_no):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to delete training orders")
        return redirect('login')
    training = get_object_or_404(TrainingOrder, training_no=training_no)
    if request.method == 'POST' :
        training.delete()
        messages.success(request, "Training order deleted successfully!")
        return redirect('hr_view_trainings')  

    return render(request, 'hr_view_trainings.html', {
        'training': training,
    })

@never_cache
def download_approved_applications(request):
    training_no = request.GET.get("training_no")

    if not training_no :
        messages.error(request, "Training number required.")
        return redirect("hr_view_applications")

    approved_applications = Application.objects.filter(
        status="Approved",
        training_order__training_no=training_no   
    )

    if not approved_applications.exists():
        messages.error(request, "No approved applications found for this training.")
        return redirect("hr_view_applications") 

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = 'attachment; filename="approved_applicants.pdf"'

    pdf = canvas.Canvas(response, pagesize=letter)
    pdf.setTitle("Approved Applicants")

    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(200, 750, "Approved Applicants List")

    styles = getSampleStyleSheet()
    table_data = [
        ["S.No", "CPF", "Name", "Designation", "Location", "Gender", "Caste", "Mobile No", "Email"]
    ]

    for index, application in enumerate(approved_applications, start=1):
        row = [
            str(index),
            str(application.cpf),
            Paragraph(application.name, styles["Normal"]), 
            Paragraph(application.designation, styles["Normal"]),  
            Paragraph(application.location, styles["Normal"]), 
            application.gender,
            application.caste,
            str(application.mobile_no),
            Paragraph(application.email, styles["Normal"]) 
        ]
        table_data.append(row)
    table = Table(table_data, colWidths=[30, 40, 100, 80, 50, 40, 50, 70, 100])


    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.white),  
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),  
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),  
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  
        ("BOTTOMPADDING", (0, 0), (-1, 0), 8),  
        ("GRID", (0, 0), (-1, -1), 1, colors.black),  
        ("WORDWRAP", (0, 0), (-1, -1), True), 
    ]))

    y_position = 700  

    if y_position - len(table_data) * 20 < 50: 
        pdf.showPage()  
        y_position = 750

    table.wrapOn(pdf, 30, y_position)
    table.drawOn(pdf, 30, y_position - (len(table_data) * 15))  

    pdf.showPage()
    pdf.save()
    response.flush()
    
    return response

@never_cache
def download_completed_trainings(request):
    training_no = request.GET.get("training_no")

    if not training_no :
        messages.error(request, "Training number required.")
        return redirect("hr_view_applications")

    completed_applications = Application.objects.filter(
        status="Approved",
        training_status="Completed",
        training_order__training_no=training_no
    )

    if not completed_applications.exists():
        messages.error(request, "No completed training applications found for this training.")
        return redirect("hr_view_applications")

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = 'attachment; filename="completed_trainings.pdf"'

    pdf = canvas.Canvas(response, pagesize=letter)
    pdf.setTitle("Completed Trainings List")
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(200, 750, "Completed Trainings - Approved Applicants")

    styles = getSampleStyleSheet()
    table_data = [
        ["S.No", "CPF", "Name", "Designation", "Location", "Gender", "Caste", "Mobile No", "Email"]
    ]

    for index, application in enumerate(completed_applications, start=1):
        row = [
            str(index),
            str(application.cpf),
            Paragraph(application.name, styles["Normal"]),
            Paragraph(application.designation, styles["Normal"]),
            Paragraph(application.location, styles["Normal"]),
            application.gender,
            application.caste,
            str(application.mobile_no),
            Paragraph(application.email, styles["Normal"])
        ]
        table_data.append(row)

    table = Table(table_data, colWidths=[30, 40, 100, 80, 50, 40, 50, 70, 100])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.white),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
        ("GRID", (0, 0), (-1, -1), 1, colors.black),
        ("WORDWRAP", (0, 0), (-1, -1), True),
    ]))

    y_position = 700
    if y_position - len(table_data) * 20 < 50:
        pdf.showPage()
        y_position = 750

    table.wrapOn(pdf, 30, y_position)
    table.drawOn(pdf, 30, y_position - (len(table_data) * 15))

    pdf.showPage()
    pdf.save()
    response.flush()

    return response


@never_cache
def hr_edit_profile(request):
    cpf = request.session.get('cpf')
    if not cpf:
        messages.error(request, "You must be logged in to edit your profile.")
        return redirect('login')

    try:
        hr = DepartmentHr.objects.get(cpf=cpf)
    except DepartmentHr.DoesNotExist:
        messages.error(request, "HR profile not found.")
        return redirect('login')

    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        designation = request.POST.get("designation")
        department = request.POST.get("department")
        mobile_no = request.POST.get("mobile_no")
        old_password = request.POST.get("old_password")
        new_password = request.POST.get("new_password")
        confirm_password = request.POST.get("confirm_password")

        
        if old_password and not check_password(old_password, hr.password):
            messages.error(request, "Old password is incorrect.")
            return redirect('hr_edit_profile')

        
        hr.name = name
        hr.email = email
        hr.designation = designation
        hr.department = department
        hr.mobile_no = mobile_no

        
        if new_password and confirm_password:
            if new_password != confirm_password:
                messages.error(request, "New passwords do not match.")
                return redirect('hr_edit_profile')
            hr.password = make_password(new_password)

        hr.save()
        return render(request, 'hr_edit_profile.html', {'show_success_modal': True})

    department_choices = [
        ('UAN', 'UAN'), ('UAS', 'UAS'), ('AAFB', 'AAFB'),
        ('BMF', 'BMF'), ('SP', 'SP'), ('LOG', 'LOG'), ('RGS', 'RGS')
    ]
    
    return render(request, "hr_edit_profile.html", {"hr": hr, "department_choices": department_choices})



def download_certificate(request, application_no):
    try:
        app = Application.objects.get(application_no=application_no)
        if app.status != "Approved" or app.training_status != "Completed":
            return HttpResponse("Certificate not available.", status=403)

        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="certificate_{application_no}.pdf"'

        p = canvas.Canvas(response, pagesize=A4)
        width, height = A4

        p.setFont("Helvetica-Bold", 28)
        p.drawCentredString(width / 2, height - 100, "Certificate of Completion")

        p.setFont("Helvetica-Oblique", 14)
        p.drawCentredString(width / 2, height - 130, "This is to certify that")

        p.setFont("Helvetica-Bold", 20)
        p.drawCentredString(width / 2, height - 170, app.name)

        p.setFont("Helvetica", 14)
        training_line = f"has successfully completed the training program titled"
        p.drawCentredString(width / 2, height - 210, training_line)

        p.setFont("Helvetica-Bold", 16)
        p.drawCentredString(width / 2, height - 240, app.training_order.training_name)

        duration_line = f"conducted from {app.training_order.start_date.strftime('%d %B %Y')} to {app.training_order.end_date.strftime('%d %B %Y')}"
        p.setFont("Helvetica", 14)
        p.drawCentredString(width / 2, height - 270, duration_line)

        p.drawCentredString(width / 2, height - 295, f"under the guidance of {app.training_order.instructor_organiser}.")

        p.drawCentredString(width / 2, height - 340, "We appreciate your dedication and wish you success in future endeavors.")

        formatted_date = date.today().strftime("%d %B %Y")
        p.setFont("Helvetica", 12)
        p.drawRightString(width - 50, 80, f"Issued on: {formatted_date}")

        p.showPage()
        p.save()

        return response
    except Application.DoesNotExist:
        return HttpResponse("Application not found.", status=404)

