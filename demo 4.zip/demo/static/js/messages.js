
document.addEventListener("DOMContentLoaded", function () {
  const modal = document.getElementById("message-modal");
  const closeButton = document.querySelector(".close-button");
  const modalText = document.getElementById("modal-message-text");

  
  const messagesData = document.body.getAttribute("data-messages");
  if (messagesData) {
      const messages = messagesData.split("|").filter(msg => msg.trim() !== "");
      if (messages.length > 0) {
          modalText.innerText = messages.join("\n");
          modal.style.display = "block";
      }
  }
  if (close-button && modal) {
    close-button.addEventListener('click', function () {
      modal.style.display = 'none';
    });
  }
  window.onload = function () {
    var modal = document.getElementById('message-modal');
    if (modal) {
        modal.style.display = 'flex';
    }
};

  window.addEventListener("click", function (event) {
      if (event.target === modal) {
          modal.style.display = "none";
      }
  });
});    
      
 function openDeleteModal(trainingNo) {
    const modal = document.getElementById('deleteModal');
    const form = document.getElementById('deleteForm');
    form.action = `/delete_training_order/${trainingNo}/`;  // Or use `{% url 'delete_training_order' training_no='__replace__' %}` pattern if passing via Django
    modal.style.display = 'flex';
}
function openProfileModal() {
  document.getElementById("profileModal").style.display = "block";
}
function closeProfileModal() {
  document.getElementById("profileModal").style.display = "none";
}

function closeDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
}
function closeMessage() {
  const modal = document.getElementById('message-modal');
  if (modal) {
    modal.style.display = 'none';
  }
}

  window.addEventListener('click', function (event) {
    const modal = document.getElementById('message-modal');
    if (event.target === modal) {
      closeMessage();
    }
  });
  function showFeedbackModal(button) {
    const appNo = button.getAttribute('data-application');
    document.getElementById('modal_app_no').value = appNo;
    document.getElementById('modal_feedback').value = '';
    document.getElementById('feedbackModal').style.display = 'block';
  }
  
  window.onclick = function(event) {
    const modal = document.getElementById('feedbackModal');
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  };
  function checkRejection(selectElement, appNo) {
    const selected = selectElement.value;
    if (selected === 'Rejected') {
        document.getElementById("feedbackModal").style.display = "block";
        document.getElementById("modal_app_no").value = appNo;
    }
}

function hideFeedbackModal() {
    document.getElementById("feedbackModal").style.display = "none";
}

function validateFeedback(form) {
    const status = form.querySelector('select[name="status"]').value;
    const feedback = form.querySelector('textarea[name="feedback"]').value.trim();
    if (status === 'Rejected' && feedback === '') {
        alert("Please enter feedback for rejection.");
        return false;
    }
    return true;
}
